import React from "react"
import { PropTypes } from "prop-types"
import styled from "styled-components"

const Description = styled.div`
  font-weight: 600;
  color: #1d1d1d;
  font-size: 20px;
`
const Label = styled.div`
  font-size: 14px;
  font-weight: 300;
  color: #878787;
  padding: 0;
  text-align: left;
`

const Content = styled.div`
  margin-right: 70px;
`

const RenderInformation = ({ label, value }) => {
  return (
    <Content>
      <Label>{label}</Label>
      <Description>
        <span>{value}</span>
      </Description>
    </Content>
  )
}

RenderInformation.propTypes = {
  label: PropTypes.string.isRequired,
  value: PropTypes.string.isRequired
}

export default RenderInformation
