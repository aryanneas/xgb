import React from "react"
import { BrowserRouter as Router, Route } from "react-router-dom"
import styled from "styled-components"

// NAVIGATION
import Nav from "./components/Nav"

// PAGES
import Home from "./pages/Home/HomePage"
import Produtos from "./pages/Produtos/Produtos"
import Clientes from "./pages/Clientes/Clientes"
import Orcamento from "./pages/Orcamento/Orcamento"

import "./index.css"

const Footer = styled.footer`
  position: absolute;
  bottom: 0;
  background-color: #f8f8f8;
  padding: 25px 0;
  width: 100%;
  text-align: center;
`

const App = () => {
  return (
    <Router>
      <div>
        <Nav />
        <div className="container">
          <Route exact={true} path="/" component={Home} />
          <Route exaxt path="/produtos" component={Produtos} />
          <Route exact path="/clientes" component={Clientes} />
          <Route exact path="/orcamento" component={Orcamento} />
        </div>
      </div>
      <Footer>© 2020 Copyright: Aryanne Silva</Footer>
    </Router>
  )
}

export default App
