import React, { useState, useEffect } from "react"
import { Field, Formik } from "formik"
import * as Yup from "yup"

import { Form } from "react-bootstrap"
import RenderInformation from "../../components/RenderInformation"

const ClientesSchema = Yup.object().shape({
  nome: Yup.string()
    .min(2, "Por favor, digite o seu nome completo!")
    .required("Required"),
  CPF: Yup.string()
    .min(5, "CPF inválido!")
    .max(11, "Ok!")
    .required("Required")
})

const renderClientes = clientes => {
  if (clientes) {
    clientes.map(cliente => (
      <>
        <RenderInformation label="Nome" value={cliente.nome} />
        <RenderInformation label="CPF" value={clientes.cpf} />
      </>
    ))
  } else return null
}

const Clientes = () => {
  const [clientes, setClientes] = useState(null)

  const getAllClientes = async () => {
    let url = "https://localhost:3000/clientes"

    await fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      }
    })
      .then(res => res.json())
      .then(json => {
        if (json.clientes) setClientes(json.clientes)
        else {
          alert(json.msg)
          window.location = "/"
        }
      })
  }

  const postCliente = async body => {
    let url = "https://localhost:3000/clientes"
    try {
      await fetch(url, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json"
        },
        body: body
      })
    } catch {
      alert("Não foi possível cadastrar o cliente")
    }
  }

  useEffect(() => {
    getAllClientes()
  }, [])

  return (
    <div className="col-md-12 d-flex row">
      <Formik
        initialValues={{
          nome: "",
          CPF: ""
        }}
        validationSchema={ClientesSchema}
        onSubmit={values => {
          postCliente(values)
        }}
      >
        <Form className="col-md-12 d-flex justify-content-center">
          <Field
            className="form-control col-md-4"
            name="nome"
            placeholder="Digite o seu nome:"
            required
          />
          <Field
            className="form-control col-md-4"
            name="CPF"
            placeholder="Digite seu CPF:"
            required
          />
          <button className="btn btn-primary col-md-2" type="submit">
            Cadastrar
          </button>
        </Form>
      </Formik>
      {renderClientes(clientes)}
    </div>
  )
}
export default Clientes
