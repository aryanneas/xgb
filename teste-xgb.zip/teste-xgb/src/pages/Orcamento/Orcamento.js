import React, { Fragment } from "react"

const Orcamento = () => (
  <Fragment>
    <h1>Orçamento</h1>
  </Fragment>
)

export default Orcamento
