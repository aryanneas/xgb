import React, { Fragment } from "react"
import styled from "styled-components"

const ImgContent = styled.div`
  display: flex;
  margin: 5% 0;
  justify-content: center;
`
const Quote = styled.p`
  text-align: center;
  text-transform: full-width;
`

const HomePage = () => (
  <Fragment>
    <h1 className="text-center">Olá, seja bem vindo(a)!</h1>
    <ImgContent>
      <img src={require("../../images/logo.png")} />
    </ImgContent>
    <Quote>"Cada um terá a vista da montanha que subir."</Quote>
  </Fragment>
)

export default HomePage
