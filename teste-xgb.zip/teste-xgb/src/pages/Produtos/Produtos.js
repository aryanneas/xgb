import React, { Fragment } from "react"

const Produtos = () => (
  <Fragment>
    <h1>Produtos</h1>
  </Fragment>
)

export default Produtos
